package com.example.fruits_tn;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class MyView extends View {
    private Paint mPaint;
    private float mAngle; // 指针旋转角度
     public MyView(Context context, AttributeSet attrs) {
         super(context, attrs);
         mPaint = new Paint();
         mPaint.setColor(Color.BLACK);
         mPaint.setStrokeWidth(10);//粗细
     }
     public void setAngle(float angle) {
         mAngle = angle;
         invalidate(); // 通知 View 重绘
     }
          @Override
          protected void onDraw(Canvas canvas) {
         super.onDraw(canvas);
         // 获取 View 的宽度和高度
           int width = getWidth();
           int height = getHeight();
           // 绘制一条直线a
//           canvas.drawLine(width / 2, 0, width / 2, height, mPaint);
           // 绘制一个指针，根据旋转角度旋转
           canvas.save();
           canvas.rotate(mAngle, width / 2, height / 2);
//           canvas.drawLine(width / 2,  height / 2 , width / 2, height / 4, mPaint);
           drawArrow(canvas,width / 2,height / 2 ,width / 2, height / 4);
           canvas.restore();
     }
    public void drawArrow(Canvas canvas, float startX, float startY, float stopX, float stopY) {
        Paint paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(5);
        canvas.drawLine(startX, startY, stopX, stopY, paint);

        double angle = Math.atan2(stopY - startY, stopX - startX) + Math.PI;
        double arrowAngle1 = angle - Math.PI / 8;
        double arrowAngle2 = angle + Math.PI / 8;
        double arrowLength = 20;//调节箭头大小

        float x1 = (float) (stopX + arrowLength * Math.cos(arrowAngle1));
        float y1 = (float) (stopY + arrowLength * Math.sin(arrowAngle1));
        canvas.drawLine(stopX, stopY, x1, y1, paint);

        float x2 = (float) (stopX + arrowLength * Math.cos(arrowAngle2));
        float y2 = (float) (stopY + arrowLength * Math.sin(arrowAngle2));
        canvas.drawLine(stopX, stopY, x2, y2, paint);
    }

}