package com.example.fruits_tn;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private MqttClient client;
    private Handler handler;
    private String host = "tcp://183.230.40.39:6002";    // TCP协议
    private String userName = "604146";             //用户名,产品id
    private String passWord = "jtc4ypFgtEJXMZAWu8RAgKjNgUg=";
    private String mqtt_id = "1082649052";          //客户端id
    private String mqtt_sub_topic = "test";
//        private String userName = "592489";             //用户名,产品id，老
//        private String passWord = "ccvV4Fx5OEnq1tS9IKf5iPR=zmM=";            //密码，老
//    private String mqtt_id = "1079136185";          //客户端id，老
//    private String mqtt_sub_topic = "/deviceA/commands";       //订阅主题，老
    private MqttConnectOptions options;
    private TextView tv_rx;
    private MyView temp_view;
    private MyView co2_view;
    private MyView hum_view;
    private MyView light_view;
    private String order = "temp:25;hum:75;CO2:400;light:35";          //订单数据
    private String temp;//存储网络传来的温度值
    private String hum;//存储网络传来的湿度值
    private String co2;//存储网络传来的CO2 值
    private String light;//存储网络传来的光照强度值
    private float tempAngle;//温度值对应的角度值
    private float humAngle;//温度值对应的角度值
    private float co2Angle;//CO2值对应的角度值
    private float lightAngle;//CO2值对应的角度值
    private float oneTemp;//第一次收到的温度值
    private float twoTemp;//第二次收到的温度值
    private float oneHum;//第一次收到的湿度值
    private float twoHum;//第二次收到的湿度值
    private float oneCO2;//第一次收到的CO2值
    private float twoCO2;//第二次收到的CO2值
    private float oneLight;//第一次收到的光照强度值
    private float twoLight;//第二次收到的光照强度值
    private Timer mTimer;
    private EditText et_input;
    private TextView tv_temp;
    private TextView tv_hum;
    private TextView tv_co2;
    private TextView tv_light;
    private static long lastClickTime = 0;
    private static final int MIN_CLICK_INTERVAL = 2000;//2秒
    private ImageView iv_alsrmT;
    private ImageView iv_alsrmH;
    private ImageView iv_alsrmC;
    private ImageView iv_alsrmL;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Mqtt_init();//初始化mqtt
        findViewById(R.id.btn_connect).setOnClickListener(this);
        findViewById(R.id.btn_disconnect).setOnClickListener(this);
        findViewById(R.id.btn_send).setOnClickListener(this);
        tv_rx = findViewById(R.id.tv_rx);
        tv_temp = findViewById(R.id.tv_Temp);
        tv_hum = findViewById(R.id.tv_Hum);
        tv_co2 = findViewById(R.id.tv_CO2);
        tv_light = findViewById(R.id.tv_Light);
        et_input = findViewById(R.id.et_input);
        //报警
        iv_alsrmT = findViewById(R.id.iv_alsrmT);
        iv_alsrmH = findViewById(R.id.iv_alsrmH);
        iv_alsrmC = findViewById(R.id.iv_alsrmC);
        iv_alsrmL = findViewById(R.id.iv_alsrmL);
        //引用控件
        temp_view = findViewById(R.id.temp_view);
        co2_view = findViewById(R.id.co2_view);
        hum_view = findViewById(R.id.hum_view);
        light_view = findViewById(R.id.light_view);
        Toast.makeText(this, "输入格式为：temp:25;hum:75;CO2:400;light:35", Toast.LENGTH_SHORT).show();

    }
    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btn_connect) {
            if (!isFastClick()) {
                try {
                    client.connect(options);
                    if(client.isConnected()) {
                        Toast.makeText(this, "连接成功", Toast.LENGTH_SHORT).show();
                        return;
                    }
                } catch (MqttException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        if(v.getId() == R.id.btn_disconnect){
            //断开连接
            try {
                if(client.isConnected()) {
                    client.disconnect();
                    Toast.makeText(this, "已断开连接", Toast.LENGTH_SHORT).show();
                }
            } catch (MqttException e) {
                throw new RuntimeException(e);
            }
        }
        if(v.getId() == R.id.btn_send) {
            //订阅并发送数据
            if (client.isConnected()){
                try {
                    order = et_input.getText().toString();
                    Mqtt_publishmessage(mqtt_sub_topic, order);
                    Toast.makeText(this, "发送成功", Toast.LENGTH_SHORT).show();
                } catch (MqttException e) {
                    throw new RuntimeException(e);
                }
            } else {
                Toast.makeText(this, "未连接，请勿发送", Toast.LENGTH_SHORT).show();
            }
        }
    }
    private void Mqtt_init()
    {
        try {
            //host为主机名，test为clientid即连接MQTT的客户端ID，一般以客户端唯一标识符表示，MemoryPersistence设置clientid的保存形式，默认为以内存保存
            client = new MqttClient(host,mqtt_id,new MemoryPersistence());
            //MQTT的连接设置
            options = new MqttConnectOptions();
            //设置mqtt版本号
            options.setMqttVersion(MqttConnectOptions.MQTT_VERSION_3_1_1);
            //设置是否清空session,这里如果设置为false表示服务器会保留客户端的连接记录，这里设置为true表示每次连接到服务器都以新的身份连接
            options.setCleanSession(false);
            //设置连接的用户名
            options.setUserName(userName);
            //设置连接的密码
            options.setPassword(passWord.toCharArray());
            // 设置超时时间 单位为秒
            options.setConnectionTimeout(10);
            // 设置会话心跳时间 单位为秒 服务器会每隔1.5*20秒的时间向客户端发送个消息判断客户端是否在线，但这个方法并没有重连的机制
            options.setKeepAliveInterval(20);
            //设置回调
            client.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {
                    //连接丢失后，一般在这里面进行重连
                    System.out.println("connectionLost----------");
                    //startReconnect();
                }
                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    //publish后会执行到这里
                    System.out.println("deliveryComplete---------"+ token.isComplete());
                }
                @Override
                public void messageArrived(String topicName, MqttMessage message) throws Exception {
                    //subscribe后得到的消息会执行到这里面
                    System.out.println("messageArrived----------");
                    Message msg = new Message();
                    msg.obj = message.toString();
                    //解包示例:temp:25;hum:75;CO2:400;light:35
                    //拆开
                    String oldStr = msg.obj.toString();
                    String[] strs = oldStr.split(";");//根据，切分字符串
//                    for(int i = 0;i < strs.length; i++){
//                        System.out.println(strs[i]);
//                    }
                    //提取数据值
                    temp = strs[0].substring(5,7);
                    hum =strs[1].substring(4);
                    co2 = strs[2].substring(4);
                    light = strs[3].substring(6);
                    //角度值
                    tempAngle = 180 * (Float.parseFloat(temp)/40)-90;
                    humAngle = 180 * (Float.parseFloat(hum)/100)-90;
                    co2Angle = 180 * (Float.parseFloat(co2)/1000)-90;
                    lightAngle = 180 * (Float.parseFloat(light)/1000)-90;
                    //超过阈值判断
                    if(tempAngle >= 90){
                        tempAngle = 90;
                    }
                    if(humAngle >= 90){
                        humAngle = 90;
                    }
                    if(co2Angle >= 90){
                        co2Angle = 90;
                    }
                    if(lightAngle >= 90){
                        lightAngle = 90;
                    }
                    //打印
                    tv_rx.setText(temp +"°C "+ hum +"% "+co2 +"ppm "+light+"lux");
                    tv_temp.setText(temp+"°C");
                    tv_hum.setText(hum+"%");
                    tv_co2.setText(co2+"ppm");
                    tv_light.setText(light+"lux");
                    //绘制数字表
                    TempDailPlate();
                    CO2DailPlate();
                    HumDailPlate();
                    LightDailPlate();
                    //调用报警
                    alsrm_temp();
                    alsrm_hum();
                    alsrm_co2();
                    alsrm_light();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // 订阅函数    (下发任务/命令)
    private void Mqtt_publishmessage(String topic,String message2) throws MqttException {
        if (client == null || !client.isConnected()) {
            //订阅主题
            client.subscribe(topic,0);
            return;
        }
        MqttMessage message = new MqttMessage();
        message.setPayload(message2.getBytes());
        try {
            client.publish(topic,message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
    //报警函数
    public void alsrm_temp(){
        //报警函数
        if(Float.parseFloat(temp) > 30){
            //发出警报
            iv_alsrmT.setImageDrawable(getResources().getDrawable(R.drawable.temp_red));
        }else {
            iv_alsrmT.setImageDrawable(getResources().getDrawable(R.drawable.temp));
        }
    }
    public void alsrm_hum(){
        //报警函数
        if(Float.parseFloat(hum) > 100){
            //发出警报
            iv_alsrmH.setImageDrawable(getResources().getDrawable(R.drawable.hum_red));
        }else {
            iv_alsrmH.setImageDrawable(getResources().getDrawable(R.drawable.hum));
        }
    }
    public void alsrm_co2(){
        //报警函数
        if(Float.parseFloat(co2) > 1000){
            //发出警报
            iv_alsrmC.setImageDrawable(getResources().getDrawable(R.drawable.cos_red));
        }else {
            iv_alsrmC.setImageDrawable(getResources().getDrawable(R.drawable.co2));
        }
    }
    public void alsrm_light(){
        //报警函数
        if(Float.parseFloat(light) > 1000){
            //发出警报
            iv_alsrmL.setImageDrawable(getResources().getDrawable(R.drawable.light_red));
        }else {
            iv_alsrmL.setImageDrawable(getResources().getDrawable(R.drawable.light));
        }
    }
    //存取前后两次的温度值
    public void updateData_Temp(float newData) {
        oneTemp = twoTemp;
        twoTemp = newData;
    }
    //存取前后两次的CO2值
    public void updateData_CO2(float newData) {
        oneCO2 = twoCO2;
        twoCO2 = newData;
    }
    //存取前后两次的湿度值
    public void updateData_Hum(float newData) {
        oneHum = twoHum;
        twoHum = newData;
    }
    //存取前后两次的光照强度值
    public void updateData_Light(float newData) {
        oneLight = twoLight;
        twoLight = newData;
    }
    //温度绘图函数
    public void TempDailPlate(){
//        temp_view.setAngle(tempAngle);
        //将初始值赋给oneAngle
        oneTemp = tempAngle;
        updateData_Temp(tempAngle);
        jiansu_Temp(oneTemp, twoTemp);
    }
    //二氧化碳绘图函数
    public void CO2DailPlate(){
//        co2_view.setAngle(co2Angle);
        //将初始值赋给oneAngle
        oneCO2 = co2Angle;
        updateData_CO2(co2Angle);
        jiansu_CO2(oneCO2, twoCO2);
    }
    //湿度绘图函数
    public void HumDailPlate(){
        //将初始值赋给oneAngle
        oneHum = humAngle;
        updateData_Hum(humAngle);
        jiansu_Hum(oneHum, twoHum);
    }
    //光照强度绘图函数
    public void LightDailPlate(){
        //将初始值赋给oneAngle
        oneLight = lightAngle;
        updateData_Light(lightAngle);
        jiansu_light(oneLight, twoLight);
    }
    //温度指针运动减速函数
    public void jiansu_Temp(float onevalue,float twovalue) {
        temp_view.setAngle(onevalue);
        tempAngle = onevalue;
        if(onevalue < twovalue) {
            //如果第一次的值小于第二次的值，顺时针
            // 每隔 100 毫秒更新一次指针的旋转角度
            mTimer = new Timer();
            mTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    //设置角度
                    tempAngle += 1;
                    if (tempAngle > twovalue) {
                        cancel();
                    }
                    temp_view.setAngle(tempAngle);
                }
            }, 0, 10);
        }
        if(onevalue > twovalue) {
            //逆时针
            // 每隔 100 毫秒更新一次指针的旋转角度
            mTimer = new Timer();
            mTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    //设置角度
                    tempAngle -= 1;
                    if (tempAngle < twovalue) {
                        cancel();
                    }
                    temp_view.setAngle(tempAngle);
                }
            }, 0, 10);
        }
    }
    //湿度指针运动减速函数
    public void jiansu_Hum(float onevalue,float twovalue) {
        hum_view.setAngle(onevalue);
        humAngle = onevalue;
        if(onevalue < twovalue) {
            //如果第一次的值小于第二次的值，顺时针
            // 每隔 100 毫秒更新一次指针的旋转角度
            mTimer = new Timer();
            mTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    //设置角度
                    humAngle += 1;
                    if (humAngle > twovalue) {
                        cancel();
                    }
                    hum_view.setAngle(humAngle);
                }
            }, 0, 10);
        }
        if(onevalue > twovalue) {
            //逆时针
            // 每隔 100 毫秒更新一次指针的旋转角度
            mTimer = new Timer();
            mTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    //设置角度
                    humAngle -= 1;
                    if (humAngle < twovalue) {
                        cancel();
                    }
                    hum_view.setAngle(humAngle);
                }
            }, 0, 10);
        }
    }
    //CO2指针运动减速函数
    public void jiansu_CO2(float onevalue,float twovalue) {
        co2_view.setAngle(onevalue);
        co2Angle = onevalue;
        if(onevalue < twovalue) {
            //如果第一次的值小于第二次的值，顺时针
            // 每隔 100 毫秒更新一次指针的旋转角度
            mTimer = new Timer();
            mTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    //设置角度
                    co2Angle += 1;
                    if (co2Angle > twovalue) {
                        cancel();
                    }
                    co2_view.setAngle(co2Angle);
                }
            }, 0, 10);
        }
        if(onevalue > twovalue) {
            //逆时针
            // 每隔 100 毫秒更新一次指针的旋转角度
            mTimer = new Timer();
            mTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    //设置角度
                    co2Angle -= 1;
                    if (co2Angle < twovalue) {
                        cancel();
                    }
                    co2_view.setAngle(co2Angle);
                }
            }, 0, 10);
        }
    }
    //光照强度指针运动减速函数
    public void jiansu_light(float onevalue,float twovalue) {
        light_view.setAngle(onevalue);
        lightAngle = onevalue;
        if(onevalue < twovalue) {
            //如果第一次的值小于第二次的值，顺时针
            // 每隔 100 毫秒更新一次指针的旋转角度
            mTimer = new Timer();
            mTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    //设置角度
                    lightAngle += 1;
                    if (lightAngle > twovalue) {
                        cancel();
                    }
                    light_view.setAngle(lightAngle);
                }
            }, 0, 10);
        }
        if(onevalue > twovalue) {
            //逆时针
            // 每隔 100 毫秒更新一次指针的旋转角度
            mTimer = new Timer();
            mTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    //设置角度
                    lightAngle -= 1;
                    if (lightAngle < twovalue) {
                        cancel();
                    }
                    light_view.setAngle(lightAngle);
                }
            }, 0, 10);
        }
    }
    //防止按钮被重复点击
    public static boolean isFastClick() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastClickTime < MIN_CLICK_INTERVAL) {
            return true;
        }
        lastClickTime = currentTime;
        return false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //取消定时器
        mTimer.cancel();
    }
}